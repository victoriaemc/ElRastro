# EL RASTRO
**Autores y Autoras:**
* Pedro José Ankersmit Carrión
* María Fernández Moreno
* Victoria Eugenia Moreno Contreras
* Andrés Pérez García
* Jaime Luis Mesa Viquez

## Uso 
Para ejecutar la aplicacion se debe ejecutar el comando `npm run prep` **en la carpeta gateway**. Después de esto se debe ejecutar el comando `npm start` en la misma carpeta.

Para acceder a la aplicación entrar en `localhost:8000` en el navegador.

## OpenAPI
Para acceder a la documentación de la API entrar en `localhost:8000/api-docs` en el navegador.